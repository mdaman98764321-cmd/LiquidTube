# LiquidTube Pro

A mobile-friendly YouTube discovery interface.

## GitHub Pages deployment
1. Create a GitHub repository and upload `index.html` and this README to the repository root.
2. Open **Settings → Pages**.
3. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. Open the published Pages URL.
5. In the app, open Settings → YouTube API connection, paste your own YouTube Data API v3 key, Save, then Test API.

## API key security
- The key is stored in this browser's localStorage and is not embedded in the GitHub source.
- A browser-side key is still visible to the person using the site and can be extracted from network requests. Do not use an unrestricted key on a public site.
- In Google Cloud Console, restrict the key to **YouTube Data API v3** and add an HTTP referrer restriction for your exact GitHub Pages domain (for example `https://YOUR-USERNAME.github.io/*`).
- Do not commit or share the key. If it was exposed, rotate it in Google Cloud Console.

## Current API features
- Search public YouTube videos using YouTube Data API v3.
- Fetch video titles, channel names, thumbnails, view counts and public like counts.
- Home and category feeds use YouTube search when a key is configured.

Note: YouTube API quota applies. Search requests use quota; repeated searches may exhaust the daily allowance. YouTube Data API does not provide a general permission to download YouTube video files.
